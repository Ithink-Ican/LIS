/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9517241379310345, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.95, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetMenu2?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru&targetDateTime=2023-12-19T07%3A15%3A38.613Z"], "isController": false}, {"data": [1.0, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetReviews?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a"], "isController": false}, {"data": [1.0, 500, 1500, "https://customer-ten-api.yumapos.ru/api/global/GetCustomerAppSettings"], "isController": false}, {"data": [1.0, 500, 1500, "https://customer-ten-api.yumapos.ru/api/promo/GetFiltered"], "isController": false}, {"data": [1.0, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetTenantDeliveryZones"], "isController": false}, {"data": [1.0, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetFiltered"], "isController": false}, {"data": [1.0, 500, 1500, "https://customer-ten-api.yumapos.ru/api/global/GetNewsList?offset=0&count=4"], "isController": false}, {"data": [0.9166666666666666, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/Get?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [1.0, 500, 1500, "https://sushiroom.pro/894eba04-6fc2-4ccd-f845-9937fdfc6f2b"], "isController": false}, {"data": [0.9, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetMenu2?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru&targetDateTime=2023-12-19T07%3A15%3A28.061Z"], "isController": false}, {"data": [1.0, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetTenantByLandingDomain?domain=sushiroom.pro"], "isController": false}, {"data": [1.0, 500, 1500, "https://sushiroom.pro/assets/i18n/full/ru.json?98"], "isController": false}, {"data": [1.0, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetMenuUpdated?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 280, 0, 0.0, 100.3321428571429, 28, 2498, 45.5, 220.0, 283.79999999999995, 956.0099999999977, 13.35113484646195, 763.9212774771123, 7.782884619969483], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetMenu2?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru&targetDateTime=2023-12-19T07%3A15%3A38.613Z", 10, 0, 0.0, 293.6, 180, 565, 236.5, 553.1, 565.0, 565.0, 0.687757909215956, 490.61391796337693, 0.4473112964236589], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetReviews?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a", 10, 0, 0.0, 64.69999999999999, 50, 85, 61.0, 84.8, 85.0, 85.0, 1.5644555694618272, 11.037661823372966, 1.023618390175219], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/global/GetCustomerAppSettings", 20, 0, 0.0, 42.2, 33, 88, 38.0, 64.40000000000003, 86.89999999999998, 88.0, 1.175295292942352, 2.2406935894987368, 0.669137847446671], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/promo/GetFiltered", 20, 0, 0.0, 71.75, 41, 274, 46.5, 250.0000000000004, 273.7, 274.0, 1.1680196227296618, 6.629880131986217, 0.7334341966945044], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetTenantDeliveryZones", 10, 0, 0.0, 64.2, 47, 111, 55.0, 108.20000000000002, 111.0, 111.0, 1.5728216420257943, 10.139323735844606, 1.144289182919157], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetFiltered", 20, 0, 0.0, 41.60000000000001, 33, 79, 37.0, 60.0, 78.04999999999998, 79.0, 1.1753643629525152, 3.091242709067936, 0.6818031558533146], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/global/GetNewsList?offset=0&count=4", 20, 0, 0.0, 46.75, 41, 55, 46.0, 54.7, 55.0, 55.0, 1.1827321111768185, 0.729332218361916, 0.6803019662921348], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/Get?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a", 30, 0, 0.0, 273.80000000000007, 53, 2498, 96.5, 723.000000000001, 2086.0499999999993, 2498.0, 1.4779781259237363, 30.656932410212832, 0.878992850280816], "isController": false}, {"data": ["Test", 10, 0, 0.0, 2809.2999999999997, 1816, 5247, 2264.5, 5130.200000000001, 5247.0, 5247.0, 0.8950147677436677, 1433.89931363555, 14.608668777409827], "isController": true}, {"data": ["https://sushiroom.pro/894eba04-6fc2-4ccd-f845-9937fdfc6f2b", 20, 0, 0.0, 195.4, 82, 362, 181.5, 307.40000000000003, 359.4, 362.0, 1.1536686663590217, 9.119502949065529, 0.6258427189086295], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetMenu2?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru&targetDateTime=2023-12-19T07%3A15%3A28.061Z", 10, 0, 0.0, 329.8, 217, 737, 253.0, 719.9000000000001, 737.0, 737.0, 1.5974440894568689, 1139.5415772264378, 1.038962659744409], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetTenantByLandingDomain?domain=sushiroom.pro", 20, 0, 0.0, 46.0, 38, 81, 43.0, 56.60000000000001, 79.79999999999998, 81.0, 1.1717148046165562, 1.5724893264104518, 0.543520050969594], "isController": false}, {"data": ["https://sushiroom.pro/assets/i18n/full/ru.json?98", 20, 0, 0.0, 48.800000000000004, 28, 89, 47.5, 70.9, 88.1, 89.0, 1.1732957878681216, 32.346412831456064, 0.49555705884078377], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetMenuUpdated?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru", 70, 0, 0.0, 35.800000000000004, 32, 53, 36.0, 39.0, 43.45, 53.0, 3.9648824695553673, 2.475617742849051, 2.431588077032002], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 280, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
