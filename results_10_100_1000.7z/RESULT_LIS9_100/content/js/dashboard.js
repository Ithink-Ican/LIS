/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 87.85714285714286, "KoPercent": 12.142857142857142};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7560344827586207, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.475, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetMenu2?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru&targetDateTime=2023-12-19T07%3A15%3A38.613Z"], "isController": false}, {"data": [0.97, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetReviews?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a"], "isController": false}, {"data": [0.985, 500, 1500, "https://customer-ten-api.yumapos.ru/api/global/GetCustomerAppSettings"], "isController": false}, {"data": [0.9975, 500, 1500, "https://customer-ten-api.yumapos.ru/api/promo/GetFiltered"], "isController": false}, {"data": [0.985, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetTenantDeliveryZones"], "isController": false}, {"data": [0.9975, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetFiltered"], "isController": false}, {"data": [0.995, 500, 1500, "https://customer-ten-api.yumapos.ru/api/global/GetNewsList?offset=0&count=4"], "isController": false}, {"data": [0.7333333333333333, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/Get?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.1375, 500, 1500, "https://sushiroom.pro/894eba04-6fc2-4ccd-f845-9937fdfc6f2b"], "isController": false}, {"data": [0.045, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetMenu2?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru&targetDateTime=2023-12-19T07%3A15%3A28.061Z"], "isController": false}, {"data": [0.99, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetTenantByLandingDomain?domain=sushiroom.pro"], "isController": false}, {"data": [0.0375, 500, 1500, "https://sushiroom.pro/assets/i18n/full/ru.json?98"], "isController": false}, {"data": [0.9957142857142857, 500, 1500, "https://customer-ten-api.yumapos.ru/api/stores/GetMenuUpdated?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2800, 340, 12.142857142857142, 447.0478571428571, 31, 9988, 91.0, 957.0, 2206.049999999993, 7264.269999999984, 97.29992702505473, 5372.1724923550055, 56.3664938579421], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetMenu2?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru&targetDateTime=2023-12-19T07%3A15%3A38.613Z", 100, 0, 0.0, 966.84, 382, 2926, 873.0, 1212.1000000000001, 2277.049999999997, 2923.7099999999987, 6.321112515802781, 4509.18388511378, 4.111192319848294], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetReviews?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a", 100, 0, 0.0, 306.7999999999999, 74, 4753, 193.0, 331.9, 444.3499999999996, 4750.839999999999, 10.598834128245892, 74.77560280869103, 6.934784048754636], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/global/GetCustomerAppSettings", 200, 0, 0.0, 147.045, 31, 759, 67.5, 368.70000000000005, 382.84999999999997, 707.9100000000001, 9.160025648071816, 17.463982492900982, 5.2151317898690115], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/promo/GetFiltered", 200, 0, 0.0, 73.36999999999996, 39, 1082, 50.0, 119.9, 184.69999999999993, 318.30000000000064, 9.83574309039048, 55.82908014286417, 6.176155085079178], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetTenantDeliveryZones", 100, 0, 0.0, 262.05999999999995, 62, 1460, 247.5, 337.70000000000005, 423.9999999999998, 1454.7199999999973, 10.638297872340425, 68.58221825132978, 7.739777260638298], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetFiltered", 200, 0, 0.0, 101.97999999999993, 31, 581, 62.0, 232.00000000000006, 289.6499999999999, 318.98, 9.303190994511118, 24.469300196529908, 5.396577588612894], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/global/GetNewsList?offset=0&count=4", 200, 0, 0.0, 67.62999999999997, 39, 614, 51.5, 81.80000000000001, 115.49999999999989, 602.5200000000023, 9.935419771485344, 6.126146842399404, 5.714806880278192], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/Get?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a", 300, 0, 0.0, 835.9300000000004, 54, 4589, 370.5, 2925.4000000000024, 3808.1499999999983, 4514.380000000003, 10.824072737768798, 224.5188925169577, 6.437363571583201], "isController": false}, {"data": ["Test", 100, 100, 100.0, 12517.339999999997, 7584, 18135, 12212.0, 16820.800000000003, 17886.699999999993, 18134.57, 5.048720149442116, 7805.0693094613025, 81.8931990584137], "isController": true}, {"data": ["https://sushiroom.pro/894eba04-6fc2-4ccd-f845-9937fdfc6f2b", 200, 152, 76.0, 513.1249999999999, 88, 3645, 203.5, 1111.5000000000002, 1809.5499999999956, 3611.4100000000035, 8.65276455827637, 33.70150395863978, 4.577515250497534], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetMenu2?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru&targetDateTime=2023-12-19T07%3A15%3A28.061Z", 100, 0, 0.0, 5179.6600000000035, 764, 9988, 4649.0, 9109.6, 9360.4, 9983.869999999997, 9.764671418806758, 6965.656677967239, 6.350850746997364], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetTenantByLandingDomain?domain=sushiroom.pro", 200, 0, 0.0, 131.83, 35, 790, 87.0, 299.70000000000005, 390.4499999999999, 692.1300000000008, 9.040365230755322, 12.133600353704288, 4.19352879356326], "isController": false}, {"data": ["https://sushiroom.pro/assets/i18n/full/ru.json?98", 200, 188, 94.0, 393.4749999999998, 79, 5828, 169.0, 783.4000000000008, 1415.55, 4165.88, 9.092148929399464, 31.872776685457108, 3.500299756785016], "isController": false}, {"data": ["https://customer-ten-api.yumapos.ru/api/stores/GetMenuUpdated?storeId=83817ed9-e1bd-4009-bc38-9ff8dde3d00a&lang=ru", 700, 0, 0.0, 62.46857142857146, 31, 1577, 36.0, 130.59999999999968, 199.0, 357.890000000001, 31.828309007411452, 19.873200066498434, 19.519705133451556], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["429/Too Many Requests", 340, 100.0, 12.142857142857142], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2800, 340, "429/Too Many Requests", 340, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://sushiroom.pro/894eba04-6fc2-4ccd-f845-9937fdfc6f2b", 200, 152, "429/Too Many Requests", 152, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https://sushiroom.pro/assets/i18n/full/ru.json?98", 200, 188, "429/Too Many Requests", 188, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
